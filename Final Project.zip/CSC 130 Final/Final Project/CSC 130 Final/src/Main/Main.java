package Main;

import java.awt.Color;
import java.util.ArrayList;
import Data.Vector2D;
import Data.spriteInfo;
import Data.BoundingBox;
import logic.Control;
import timer.stopWatchX;

public class Main {
    // Fields (Static) below...
    public static Color c = new Color(200, 80, 25);
    public static stopWatchX timer = new stopWatchX(100);
    public static ArrayList<spriteInfo> sprites = new ArrayList<>();
    public static int currentSpriteIndex = 0;
    public static String trigger = "";
    public static String direction = "";
    public static String lastFacingDirection = ""; 
    public static int x = 560;
    public static int y = 70;

    //BoundingBox objects
    public static BoundingBox borderBox;
    public static BoundingBox borderBox2;
    public static BoundingBox borderBox3;
    public static BoundingBox borderBox4;
    public static BoundingBox cowBox;
    public static BoundingBox barnBox;
    public static BoundingBox cornBox;

    public static BoundingBox spriteBox = new BoundingBox(x, y, x + 70, y + 110);

    public static void main(String[] args) {
        Control ctrl = new Control(); // Do NOT remove!
        ctrl.gameLoop(); // Do NOT remove!
    }

    /* This is your access to things BEFORE the game loop starts */
    public static void start() {

        String[] tags = {"JL", "U1", "U2", "U3", "U4", "U3", "U2", "L1", "L2", "L3", "L4",
                "L5", "L6", "L7", "L1", "D1", "D2", "D4", "D3", "D4", "D2",
                "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"};
        for (int i = 0; i < tags.length; i++) {
            Vector2D coordinates = new Vector2D(x, y);
            spriteInfo sprite = new spriteInfo(coordinates, tags[i]);
            sprites.add(sprite);
        }

        //BoundingBox objects
        borderBox = new BoundingBox(0, 0, 1240, 20);
        cowBox = new BoundingBox(420, 365, 555, 500);
        barnBox = new BoundingBox(870, 170, 1000, 305);
        cornBox = new BoundingBox(800, 535, 1200, 620);
        borderBox2 = new BoundingBox(0, 0, 13, 670);
        borderBox3 = new BoundingBox(1235, 0, 1240, 670);
        borderBox4 = new BoundingBox(0, 670, 1240, 680);
    }

    /* This is your access to the "game loop" (It is a "callback" method from the Control class (do NOT modify that class!))*/
    public static void update(Control ctrl) {
        ctrl.addSpriteToFrontBuffer(0, 0, "B");

        // Debug information
        ctrl.drawString(40, 50, "Trigger: " + trigger, c);
        ctrl.drawString(40, 70, "Direction: " + direction, c);
        ctrl.drawString(40, 90, "Collision: " + isColliding(), c);
        ctrl.drawString(40, 110, "X: " + x + " Y: " + y, c);

        ctrl.addSpriteToFrontBuffer(445, 370, "cow");
        ctrl.addSpriteToFrontBuffer(895, 172, "barn");
        ctrl.addSpriteToFrontBuffer(820, 533, "corn");

        movePlayer(); //movePlayer method

        boolean collisionStatus = checkCollision();

        if (collisionStatus) {
            
            x = prevX;
            y = prevY;
        }
        
        int startIndex;
        int endIndex;

        switch (direction) {
            case "w":
                startIndex = 3; 
                endIndex = 6;
                lastFacingDirection = "w"; 
                break;
            case "a":
                startIndex = 8; 
                endIndex = 14;
                lastFacingDirection = "a"; 
                break;
            case "s":
                startIndex = 16; 
                endIndex = 20;
                lastFacingDirection = "s"; 
                break;
            case "d":
                startIndex = 22; 
                endIndex = 28;
                lastFacingDirection = "d"; 
                break;
            default:
                startIndex = getStartIndexForLastFacingDirection();
                endIndex = startIndex; 
                break;
        }

        if (currentSpriteIndex < startIndex || currentSpriteIndex > endIndex) {
            currentSpriteIndex = startIndex;
        }

        ctrl.addSpriteToFrontBuffer(x, y, sprites.get(currentSpriteIndex).getTag());

        if (!collisionStatus) {
            currentSpriteIndex++;
            if (currentSpriteIndex > endIndex) {
                currentSpriteIndex = startIndex;
            }
        }

        timer.resetWatch();
        while (!timer.isTimeUp()) {
        }
    }

    private static int getStartIndexForLastFacingDirection() {
        switch (lastFacingDirection) {
            case "w":
                return 3;
            case "a":
                return 9;
            case "s":
                return 16;
            case "d":
                return 23;
            default:
                return 0;
        }
    }

    private static int prevX = x;
    private static int prevY = y;

    public static void movePlayer() {
        
        prevX = x;
        prevY = y;

        switch (direction) {
            case "w":
                y -= 15;
                break;
            case "a":
                x -= 15;
                break;
            case "s":
                y += 15;
                break;
            case "d":
                x += 15;
                break;
        }

        spriteBox.updatePlayerBox(x, y, x + 70, y + 110);

        if (borderBox.contains(spriteBox)) {
            x = prevX;
            y = prevY;
        }
    }

    public static boolean checkCollision() {
        return cowBox.intersects(spriteBox) || barnBox.intersects(spriteBox) || borderBox.intersects(spriteBox) || borderBox2.intersects(spriteBox) || borderBox3.intersects(spriteBox) || borderBox4.intersects(spriteBox) ||cornBox.intersects(spriteBox);
    }

    public static boolean isColliding() {
        return checkCollision();
    }
}
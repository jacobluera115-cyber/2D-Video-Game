package Main;

import logic.Control;
import timer.stopWatchX;

public class KeyProcessor {
    // Static Fields
    private static char last = ' ';            // For debouncing purposes
    private static stopWatchX sw = new stopWatchX(250);

    // Static Method(s)
    public static void processKey(char key) {
        if (key == ' '){
        	Main.direction = ""; 
        	return;
    }
        // Debounce routine below...
        	if (key == last)
            if (sw.isTimeUp() == false) return;
        last = key;
        sw.resetWatch();

        /* TODO: You can modify values below here! */
        switch (key) {
            case 'w':
                Main.trigger = key + " is triggered";
                Main.direction = Character.toString(key);
                break;
            case 'a':
                Main.trigger = key + " is triggered";
                Main.direction = Character.toString(key);
                break;
            case 's':
                Main.trigger = key + " is triggered";
                Main.direction = Character.toString(key);
                break;
            case 'd':
                Main.trigger = key + " is triggered";
                Main.direction = Character.toString(key);
                break;
            case 'h':
                Main.trigger = key + " is triggered";
                Main.direction = ""; // Stop the sprite movement
            case '$':
                Main.trigger = key + " is triggered";
                break;
            case '%':                                // ESC key
                System.exit(0);
                break;
            case 'm':
                // For mouse coordinates
                Control.isMouseCoordsDisplayed = !Control.isMouseCoordsDisplayed;
                break;
        }
    }
}

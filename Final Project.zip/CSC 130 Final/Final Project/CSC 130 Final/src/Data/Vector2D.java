/* This class is used to give you a handy way to pass a pair of 2D coordinates as a single object. The behavior (methods) of the class should allow for robust options in the future. */

package Data;

public class Vector2D {
	// Fields
	private int CoordinateX;
	private int CoordinateY;
	// Constructor
	public Vector2D(int x, int y){
		this.CoordinateX = x;
		this.CoordinateY = y;
	}
	// Methods
	public int getX(){
		return CoordinateX;
	}
	public int getY(){
		return CoordinateY;
	}
	public void setX(int newX){
		CoordinateX = newX;
	}
	public void setY(int newY){
		CoordinateY = newY;
	}
	public void adjustX(int adjustment){
		// Backward adjustments can be made by passing a negative number as an adjustment
		CoordinateX += adjustment;
	}
	public void adjustY(int adjustment){
		// Backward adjustments can be made by passing a negative number as an adjustment
		 CoordinateY += adjustment;
	}
}